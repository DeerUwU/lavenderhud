silly little hud.

for anyone editing the hud:
lines commented out with //// are for customization options, dont edit these unless you know what youre doing.